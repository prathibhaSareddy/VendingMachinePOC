package com.hca.poc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hca.poc.model.Soda;
import com.hca.poc.service.VendingMachineService;

@Controller
@RequestMapping("/vending")
public class VendingMachineController {
	@Autowired
	VendingMachineService service;

	@GetMapping("/home")
	public String listAvailableInventory(Model model) {
		List<Soda> sodaList = service.listInventory();
		model.addAttribute("listSodas", sodaList);
		return "home";
	}

	@GetMapping("/buy/{id}")
	public String dispenseSoda(@PathVariable("id") int id, Model model) {
		String retrunString = "fail";
		try {
			Soda soda = new Soda();
			int change = service.dispenseSoda(id, soda);
			model.addAttribute("sodaName", soda.getName());
			model.addAttribute("change", change);
			retrunString = "success";
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			retrunString = "fail";
		}
		return retrunString;

	}

}
