package com.hca.poc.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hca.poc.model.Soda;

@Repository
public interface SodaRepository extends CrudRepository<Soda, Integer>{

}
