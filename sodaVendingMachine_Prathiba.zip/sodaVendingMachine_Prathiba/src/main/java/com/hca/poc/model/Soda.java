package com.hca.poc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SODA_INVENTORY")
public class Soda {
	@Id
	@Column(name = "ID")
	public int id;
	
	@Column(name = "SODA_NAME")
	public String name;
	
	@Column(name = "PRICE")
	public int price;
	
	@Column(name = "QUANTITY")
	public int quantity;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	

}
