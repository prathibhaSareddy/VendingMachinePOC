package com.hca.poc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hca.poc.model.Soda;

@Service
public interface VendingMachineService {
	public List<Soda> listInventory();

	public int dispenseSoda(int id, Soda soda) throws Exception;
}
