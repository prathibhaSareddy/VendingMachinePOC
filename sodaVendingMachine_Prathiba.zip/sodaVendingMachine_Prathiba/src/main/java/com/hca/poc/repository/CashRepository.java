package com.hca.poc.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hca.poc.model.Cash;

@Repository
public interface CashRepository extends CrudRepository<Cash, Integer>{

}
