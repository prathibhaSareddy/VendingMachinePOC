package com.hca.poc.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Cash {
	
	@Id
	public int id;
	public int cents;
	public int quarters;
	public int getNumOfCents() {
		return cents;
	}
	public void setNumOfCents(int cents) {
		this.cents = cents;
	}
	public int getNumofQuarters() {
		return quarters;
	}
	public void setNumofQuarters(int quarters) {
		this.quarters = quarters;
	}

}
