package com.hca.poc.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hca.poc.model.PurchaseInfo;

@Repository
public interface PurchaseInfoRepository extends CrudRepository<PurchaseInfo, Integer>{
	
}
