package com.hca.poc.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hca.poc.model.Cash;
import com.hca.poc.model.PurchaseInfo;
import com.hca.poc.model.Soda;
import com.hca.poc.repository.CashRepository;
import com.hca.poc.repository.PurchaseInfoRepository;
import com.hca.poc.repository.SodaRepository;

@Service
public class VendingMachineServiceImpl implements VendingMachineService {
	@Autowired
	SodaRepository sodaRepository;

	@Autowired
	PurchaseInfoRepository purchaseInfoRepository;

	@Autowired
	CashRepository cashRepository;

	@Override
	public List<Soda> listInventory() {
		List<Soda> list = new ArrayList<Soda>();
		sodaRepository.findAll().forEach(soda -> list.add(soda));
		return list;
	}

	@Override
	public int dispenseSoda(int id, Soda soda) throws Exception {
		soda = sodaRepository.findById(id).get();
		int change = 0;
		if (ifSodaAvailable(soda)) {
			if (checkIfChangeIsAvailable(soda)) {
				change = dispenseSodaAndChange(soda);
				savePurchaseInfo(soda);
			}
		}
		return change;
	}

	private void savePurchaseInfo(Soda soda) {
		PurchaseInfo purchaseInfo = new PurchaseInfo();
		purchaseInfo.setName(soda.getName());
		purchaseInfo.setPurchaseDate(new Timestamp(new Date().getTime()));
		purchaseInfoRepository.save(purchaseInfo);
	}

	private int dispenseSodaAndChange(Soda soda) {
		int price = soda.getPrice();
		int change = 25 - price;
		soda.setQuantity(soda.getQuantity() - 1);
		sodaRepository.save(soda);

		Cash cash = cashRepository.findById(1).get();
		cash.setNumOfCents(cash.getNumOfCents() - change);
		cash.setNumofQuarters(cash.getNumofQuarters() + 1);
		cashRepository.save(cash);
		return change;

	}

	private boolean checkIfChangeIsAvailable(Soda soda) throws Exception {
		Cash cash = cashRepository.findById(1).get();
		if (cash.getNumOfCents() >= (25 - soda.getPrice()))
			return true;
		else
			throw new Exception("Change is not available. we hope to give better service next time ");
	}

	private boolean ifSodaAvailable(Soda soda) throws Exception {
		if (soda.getQuantity() > 0)
			return true;
		else {
			throw new Exception("Selected Soda is not available. we hope to give better service next time ");
		}
	}

}
